import { Link } from 'react-router-dom'

function Navbar() {
  return (
    <nav className="bg-primary border-b border-slate-800 px-6 py-4 flex items-center justify-between">
      <Link to="/" className="text-2xl font-bold text-accent">
        FlowPay
      </Link>
      <div className="flex gap-6 text-sm text-slate-400">
        <Link to="/payment-links" className="hover:text-white transition">Payment Links</Link>
        <Link to="/escrow" className="hover:text-white transition">Escrow</Link>
        <Link to="/bulk-payouts" className="hover:text-white transition">Bulk Payouts</Link>
        <Link to="/wallet" className="hover:text-white transition">Wallet</Link>
      </div>
      <button className="bg-accent text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-500 transition">
        Connect Wallet
      </button>
    </nav>
  )
}

export default Navbar
