import { Link } from 'react-router-dom'
import { Link2, Lock, Send, BarChart2 } from 'lucide-react'

const features = [
  {
    icon: <Link2 className="w-6 h-6 text-accent" />,
    title: 'Payment Links',
    desc: 'Generate a shareable link and get paid in XRP instantly.',
    path: '/payment-links',
  },
  {
    icon: <Lock className="w-6 h-6 text-accent" />,
    title: 'Escrow Contracts',
    desc: 'Lock funds trustlessly. Release on delivery. No middleman.',
    path: '/escrow',
  },
  {
    icon: <Send className="w-6 h-6 text-accent" />,
    title: 'Bulk Payouts',
    desc: 'Pay your entire team or community in one click via CSV.',
    path: '/bulk-payouts',
  },
  {
    icon: <BarChart2 className="w-6 h-6 text-accent" />,
    title: 'Wallet Dashboard',
    desc: 'Track any XRPL wallet — activity, portfolio, history.',
    path: '/wallet',
  },
]

function Home() {
  return (
    <div className="max-w-5xl mx-auto px-6 py-20">
      <div className="text-center mb-16">
        <h1 className="text-5xl font-bold text-white mb-4">
          Payments, Simplified on <span className="text-accent">XRPL</span>
        </h1>
        <p className="text-slate-400 text-lg max-w-xl mx-auto">
          FlowPay is a complete payment platform for freelancers and crypto teams — built on the XRP Ledger.
        </p>
        <div className="mt-8 flex gap-4 justify-center">
          <Link to="/payment-links" className="bg-accent text-white px-6 py-3 rounded-lg font-medium hover:bg-indigo-500 transition">
            Get Started
          </Link>
          <Link to="/wallet" className="border border-slate-700 text-slate-300 px-6 py-3 rounded-lg font-medium hover:border-slate-500 transition">
            View Wallet
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {features.map((f) => (
          <Link to={f.path} key={f.title} className="bg-slate-800 rounded-xl p-6 hover:bg-slate-700 transition border border-slate-700">
            <div className="mb-3">{f.icon}</div>
            <h3 className="text-white font-semibold text-lg mb-1">{f.title}</h3>
            <p className="text-slate-400 text-sm">{f.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}

export default Home
