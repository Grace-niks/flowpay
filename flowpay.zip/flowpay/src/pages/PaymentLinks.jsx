function PaymentLinks() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-white mb-2">Payment Links</h1>
      <p className="text-slate-400 mb-8">Generate a shareable link and get paid in XRP instantly.</p>
      <div className="bg-slate-800 rounded-xl p-8 border border-slate-700">
        <p className="text-slate-400 text-center">Coming soon — connect your wallet to create a payment link.</p>
      </div>
    </div>
  )
}

export default PaymentLinks
