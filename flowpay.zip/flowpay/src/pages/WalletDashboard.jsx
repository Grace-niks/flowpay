function WalletDashboard() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-white mb-2">Wallet Dashboard</h1>
      <p className="text-slate-400 mb-8">Track any XRPL wallet — activity, portfolio, and history.</p>
      <div className="bg-slate-800 rounded-xl p-8 border border-slate-700">
        <p className="text-slate-400 text-center">Coming soon — enter a wallet address to view activity.</p>
      </div>
    </div>
  )
}

export default WalletDashboard
