function Escrow() {
  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="text-3xl font-bold text-white mb-2">Escrow Contracts</h1>
      <p className="text-slate-400 mb-8">Lock funds trustlessly on XRPL. Release on delivery.</p>
      <div className="bg-slate-800 rounded-xl p-8 border border-slate-700">
        <p className="text-slate-400 text-center">Coming soon — connect your wallet to create an escrow.</p>
      </div>
    </div>
  )
}

export default Escrow
